import { Component } from '@angular/core';
import { ChartModule } from 'angular2-chartjs';


@Component({
  selector: 'ngx-echarts',
  styleUrls: ['./echarts.component.scss'],
  templateUrl: './echarts.component.html',
})
export class EchartsComponent {}
