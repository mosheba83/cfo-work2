import { AfterViewInit, Component, OnDestroy, Input } from '@angular/core';
import { NbThemeService } from '@nebular/theme';
import { PieChartServiceService} from './pie-chart-service.service';



@Component({
  selector: 'ngx-echarts-pie',
  template: `
    <div echarts [options]="options" class="echart"></div>
  `,
})
export class EchartsPieComponent implements AfterViewInit, OnDestroy {
  @Input() public options: any = {};
  themeSubscription: any;
  @Input() public dataLedend :Array<any>;
  @Input() public dataForSeries :Array<any>;


  constructor(private theme: NbThemeService,private pieService: PieChartServiceService) {
    console.log("constructor");
    this.dataLedend  = [];
    this.dataForSeries  = [];
  }
  


  ngAfterViewInit() {
      console.log("ngAfterViewInit");
    this.themeSubscription = this.theme.getJsTheme().subscribe(config => {

      const colors = config.variables;
      const echarts: any = config.variables.echarts;
      this.options = {
        backgroundColor: echarts.bg,
        color: ['#ffa100', '#00d977', '#0088ff'],
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b} : {c} ({d}%)',
        },
        legend: {
          orient: 'vertical',
          left: 'left',
          data: this.dataLedend,
          textStyle: {
            color:'#ffffff',
          },
        },
        series: [
          {
            name: 'Currencies',
            type: 'pie',
            radius: '80%',
            center: ['50%', '50%'],
            data:this.dataForSeries,
            itemStyle: {
              emphasis: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)',
              },
            },
            label: {
              normal: {
                textStyle: {
                  color:  '#ffffff',
                },
              },
            },
            labelLine: {
              normal: {
                lineStyle: {
                  color:'#a1a1e5',
                },
              },
            },
          },
        ],
      };
    });
  }

  ngOnDestroy(): void {
    this.themeSubscription.unsubscribe();
  }
}
