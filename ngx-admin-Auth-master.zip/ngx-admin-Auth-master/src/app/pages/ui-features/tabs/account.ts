export class Account {
    _id?: string;
    account_no: string;
    currency: string;
    amount: string;
    bank: string;
    type: string;
    bank_img:string;
    
  }