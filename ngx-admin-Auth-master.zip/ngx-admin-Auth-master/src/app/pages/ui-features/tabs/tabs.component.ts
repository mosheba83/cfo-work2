import { Component } from '@angular/core';
import { Account } from '../../account';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AccountService } from '../../account.service';
import { AwsService } from '../../../newlogin/myauth/aws.service';
import { AfterViewInit, OnDestroy } from '@angular/core';
import { NbThemeService } from '@nebular/theme';
import { EchartsPieComponent} from './echarts-pie.component';
import { ChartModule } from 'angular2-chartjs';
import { PieChartServiceService} from './pie-chart-service.service';
import { EchartsBarComponent } from './echarts-bar.component';



@Component({ /*Accounts */
  selector: 'ngx-tab1',
  template: `
  <div class="row">
  <div class="col-lg-6">
    <nb-card>
      <nb-card-header>
        <div class="row"> 
        <div [(ngModel)]="dividedButtonGroupOne" ngbRadioGroup
               class="btn-group btn-divided-group btn-outline-divided-group btn-group-full-width col-md-8">
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="checkingFilter()">
              <input ngbButton type="radio" value="left"> Checking
            </label>
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="shortTermFilter()">
              <input ngbButton type="radio" value="middle"> Short Term
            </label>
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="longTermFilter()">
              <input ngbButton type="radio" value="right"> Long Term
            </label>
          </div>
        </div>
      </nb-card-header>
      <nb-card-body>
      <div  *ngFor="let account of selectedAccounts">
        <div class="col-lg-12">
          <nb-card> 
            <nb-card-header>
            <div>
            <h6 ><b>Account&nbsp;:</b>  &nbsp; {{account.account_no}} <img src={{account.bank_img}} style="width:50px;" align="right"/></h6>       
           </div>
            </nb-card-header>
            <nb-card-body>
            <div>
              <h6 ><b>Balance&nbsp;:</b>&nbsp; {{account.amount}}  &nbsp;&nbsp; {{account.currency}}
              <button class="btn btn-primary btn-tn" style="float: right;" >Move Funds</button>&nbsp;&nbsp;
              </h6>  
              </div>            
            </nb-card-body>
          </nb-card>
        </div>
        </div>
      </nb-card-body>
    </nb-card>
  </div>
  <div class="col-lg-6">
<nb-card>
  <nb-card-header>Currencies</nb-card-header>
    <nb-card-body>
      <ngx-echarts-pie [dataLegend]="dataLegend" [dataForSeries]="dataForSeries" [options]="options"></ngx-echarts-pie>
      <ngx-echarts-bar [xAxisData]="xAxisDataBanks" [dataSeriesSums]="dataSeriesSumsBanks" [options]="optionsBarBanks"></ngx-echarts-bar>
      </nb-card-body>
</nb-card>
</div>
</div>


  `,
  //providers: [AccountService]
})
export class Tab1Component   {
  accounts: Account[] = [];
  selectedAccounts :Account[]   = [];
  account1: Account = new Account();
  account2: Account = new Account();
  account3: Account = new Account();
  account4: Account = new Account();
  account5: Account = new Account();
  account6: Account = new Account();
  account7: Account = new Account();
  account8: Account = new Account();

  options: any = {};
  themeSubscription: any;
  dataLegend :Array<any>;
  dataForSeries :Array<any>;

  optionsBarBanks: any = {};
  themeSubscriptionBarBanks: any;
  xAxisDataBanks :Array<any>; // represents the name of the account types
  dataSeriesSumsBanks :Array<any>;

  
  constructor(private accountService: AccountService,public awsService:AwsService,private theme: NbThemeService
  ,private pieService:PieChartServiceService) {

  
    
    this.accountService
    .getOverallbalance()
    .then((accounts: Account[]) => {
      this.accounts = this.accounts.concat(accounts.map((account) => {
        if (!account.account_no) {
          account.account_no = 'no number';
        }
        return account;
      }));
    });
    this.account1.account_no = '111111';
    this.account1.amount = '1000';
    this.account1.currency = 'USD';
    this.account1.bank = 'Nordea';
    this.account1.type = 'Checking';
    this.account1.bank_img = 'assets/images/nordea.png';

    this.account2.account_no = '2222222';
    this.account2.amount = '2000';
    this.account2.currency = 'GBP';
    this.account2.bank = 'Nordea';
    this.account2.type = 'Short Term';
    this.account2.bank_img = 'assets/images/nordea.png'


    this.account3.account_no = '33333333';
    this.account3.amount = '3000';
    this.account3.currency = 'USD';
    this.account3.bank = 'Nordea';
    this.account3.type = 'Checking';
    this.account3.bank_img = 'assets/images/nordea.png'


    this.account4.account_no = '4444444444';
    this.account4.amount = '4000';
    this.account4.currency = 'GBP';
    this.account4.bank = 'RBS';
    this.account4.type = 'Long Term';
    this.account4.bank_img = 'assets/images/rbs_round.png'


    this.account5.account_no = '55555555';
    this.account5.amount = '5000';
    this.account5.currency = 'EUR';
    this.account5.bank = 'RBS';
    this.account5.type = 'Checking';
    this.account5.bank_img = 'assets/images/rbs_round.png'


    this.account6.account_no = '66666666';
    this.account6.amount = '6000';
    this.account6.currency = 'EUR';
    this.account6.bank = 'RBS';
    this.account6.type = 'Short Term';
    this.account6.bank_img = 'assets/images/rbs_round.png'


    this.account7.account_no = '777777777';
    this.account7.amount = '7000';
    this.account7.currency = 'GBP';
    this.account7.bank = 'Starling';
    this.account7.type = 'Long Term';
    this.account7.bank_img = 'assets/images/starling_round.png'


    this.account8.account_no = '888888888';
    this.account8.amount = '8000';
    this.account8.currency = 'USD';
    this.account8.bank = 'Starling';
    this.account8.type = 'Checking';
    this.account8.bank_img = 'assets/images/starling_round.png'


    this.accounts.push(this.account1);
    this.accounts.push(this.account2);
    this.accounts.push(this.account3);
    this.accounts.push(this.account4);
    this.accounts.push(this.account5);
    this.accounts.push(this.account6);
    this.accounts.push(this.account7);
    this.accounts.push(this.account8);

    this.checkingFilter();

  }

  checkingFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].type.trim().toUpperCase()== 'Checking'.toUpperCase()){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptions(this.selectedAccounts);
    this.setPieOptionsBarBanks(this.selectedAccounts);
  }

  shortTermFilter(){
    console.log('shortTermFilter');
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].type.trim().toUpperCase() == 'Short Term'.toUpperCase()){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptions(this.selectedAccounts);
    this.setPieOptionsBarBanks(this.selectedAccounts);
  }

  longTermFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].type.trim().toUpperCase() == 'Long Term'.toUpperCase()){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptions(this.selectedAccounts);
    this.setPieOptionsBarBanks(this.selectedAccounts);
  }

  setPieOptions(selectedAccounts:Array<any>){
    console.log('setPieOptions');
    this.dataLegend = [];
    for(var i =0; i< selectedAccounts.length; i++){
      if (!this.dataLegend.includes(selectedAccounts[i].currency.trim().toUpperCase())){
        this.dataLegend.push(selectedAccounts[i].currency.trim().toUpperCase());
      }
    }

    let dataSeriesSums:number[]= [];
    for(var i =0; i<this.dataLegend.length; i++){
      dataSeriesSums[i]=0;
    }
    for(var i =0; i< selectedAccounts.length; i++){
      for(var j =0; j<this.dataLegend.length; j++){
        if (selectedAccounts[i].currency.trim().toUpperCase()==this.dataLegend[j].trim().toUpperCase()){
          dataSeriesSums[j] +=Number(selectedAccounts[i].amount);
        }
      }
    }

    this.dataForSeries = [];
    for(var i =0; i<this.dataLegend.length; i++){
      this.dataForSeries.push({value: dataSeriesSums[i], name: this.dataLegend[i]});
    }

    console.log("dataLedend");
    console.log(this.dataLegend);
    console.log("dataSeriesSums");
    console.log(dataSeriesSums);
    console.log("dataForSeries");
    console.log(this.dataForSeries);


    this.options = {
      backgroundColor: echarts.bg,
      color: ['#ffa100', '#00d977', '#0088ff'],
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)',
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        data: this.dataLegend,
        textStyle: {
          color: '#ffffff',
        },
      },
      series: [
        {
          name: 'Currencies',
          type: 'pie',
          radius: '80%',
          center: ['50%', '50%'],
          data:this.dataForSeries,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
          },
          label: {
            normal: {
              textStyle: {
                color:'#ffffff',
              },
            },
          },
          labelLine: {
            normal: {
              lineStyle: {
                color: '#a1a1e5',
              },
            },
          },
        },
      ],
    };

    //this.pieService.setOptions(this.dataLegend,this.dataForSeries);
  }

  setPieOptionsBarBanks(selectedAccounts:Array<any>){
    console.log('setPieOptions');
    this.xAxisDataBanks = [];
    for(var i =0; i< selectedAccounts.length; i++){
      if (!this.xAxisDataBanks.includes(selectedAccounts[i].bank.trim().toUpperCase())){
        this.xAxisDataBanks.push(selectedAccounts[i].bank.trim().toUpperCase());
      }
    }

    this.dataSeriesSumsBanks = [];
    for(var i =0; i<this.xAxisDataBanks.length; i++){
      this.dataSeriesSumsBanks[i]=0;
    }
    for(var i =0; i< selectedAccounts.length; i++){
      for(var j =0; j<this.xAxisDataBanks.length; j++){
        if (selectedAccounts[i].bank.trim().toUpperCase()==this.xAxisDataBanks[j].trim().toUpperCase()){
          this.dataSeriesSumsBanks[j] +=Number(selectedAccounts[i].amount);
        }
      }
    }



    console.log("xAxisData");
    console.log(this.xAxisDataBanks);
    console.log("dataSeriesSums");
    console.log(this.dataSeriesSumsBanks);

   // const colors: any = config.variables;


    this.optionsBarBanks = {
      backgroundColor: echarts.bg,
      color: ['#0088ff'],
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true,
      },
      xAxis: [
        {
          type: 'category',
          data: this.xAxisDataBanks,//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          axisTick: {
            alignWithLabel: true,
          },
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      yAxis: [
        {
          type: 'value',
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          splitLine: {
            lineStyle: {
              color: '#342e73',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      series: [
        {
          name: 'Score',
          type: 'bar',
          barWidth: '60%',
          data:this.dataSeriesSumsBanks,//[10, 52, 200, 334, 390, 330, 220],
        },
      ],
    };

    //this.pieService.setOptions(this.dataLegend,this.dataForSeries);
  }
 }

@Component({/*Currencies */
  selector: 'ngx-tab2',
  template: `
  <div class="row">
  <div class="col-lg-6">
    <nb-card>
      <nb-card-header>
        <div class="row">
          <div [(ngModel)]="dividedButtonGroupOne" ngbRadioGroup
               class="btn-group btn-divided-group btn-outline-divided-group btn-group-full-width col-md-8">
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="usdFilter()">
              <input ngbButton type="radio" value="left"> USD
            </label>
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="gbpFilter()">
              <input ngbButton type="radio" value="middle"> GBP
            </label>
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="eurFilter()">
              <input ngbButton type="radio" value="right"> EUR
            </label>
          </div>
        </div>
      </nb-card-header>
      <nb-card-body>
      <div  *ngFor="let account of selectedAccounts">
        <div class="col-lg-12">
        <nb-card> 
        <nb-card-header>
        <div>
        <h6 ><b>Account&nbsp;:</b>  &nbsp; {{account.account_no}} &nbsp; - &nbsp; {{account.type}} <img src={{account.bank_img}} style="margin:auto; width:50px;" align="right"/></h6>       
       </div>
        </nb-card-header>
        <nb-card-body>
        <div>
          <h6 ><b>Balance&nbsp;:</b>&nbsp; {{account.amount}}
          <button class="btn btn-primary btn-tn" style="float: right;" >Move Funds</button>&nbsp;&nbsp;
          </h6>  
          </div>            
        </nb-card-body>
      </nb-card>
        </div>
        </div>
      </nb-card-body>
    </nb-card>
  </div>
  <div class="col-lg-6">
  <nb-card>
    <nb-card-header>Accounts</nb-card-header>
      <nb-card-body>
        <ngx-echarts-bar [xAxisData]="xAxisData" [dataSeriesSums]="dataSeriesSums" [options]="optionsBar"></ngx-echarts-bar>
        <ngx-echarts-bar [xAxisData]="xAxisDataBanks" [dataSeriesSums]="dataSeriesSumsBanks" [options]="optionsBarBanks"></ngx-echarts-bar>
        </nb-card-body>
  </nb-card>
</div>
</div>

  `,
  //providers: [AccountService]
})
export class Tab2Component { 

  accounts: Account[] = [];
  selectedAccounts :Account[]   = [];
  account1: Account = new Account();
  account2: Account = new Account();
  account3: Account = new Account();
  account4: Account = new Account();
  account5: Account = new Account();
  account6: Account = new Account();
  account7: Account = new Account();
  account8: Account = new Account();

  optionsBar: any = {};
  themeSubscriptionBar: any;
  xAxisData :Array<any>; // represents the name of the account types
  dataSeriesSums :Array<any>;


  optionsBarBanks: any = {};
  themeSubscriptionBarBanks: any;
  xAxisDataBanks :Array<any>; // represents the name of the account types
  dataSeriesSumsBanks :Array<any>;

  constructor(private accountService: AccountService) {


    this.accountService
    .getOverallbalance()
    .then((accounts: Account[]) => {
      this.accounts = this.accounts.concat(accounts.map((account) => {
        if (!account.account_no) {
          account.account_no = 'no number';
        }
        return account;
      }));
    });
    this.account1.account_no = '111111';
    this.account1.amount = '1000';
    this.account1.currency = 'USD'
    this.account1.bank = 'Nordea'
    this.account1.type = 'Checking'
    this.account1.bank_img = 'assets/images/nordea.png'

    this.account2.account_no = '2222222';
    this.account2.amount = '2000';
    this.account2.currency = 'GBP'
    this.account2.bank = 'Nordea'
    this.account2.type = 'Short Term'
    this.account2.bank_img = 'assets/images/nordea.png'

    this.account3.account_no = '33333333';
    this.account3.amount = '3000';
    this.account3.currency = 'USD'
    this.account3.bank = 'Nordea'
    this.account3.type = 'Checking'
    this.account3.bank_img = 'assets/images/nordea.png'

    this.account4.account_no = '4444444444';
    this.account4.amount = '4000';
    this.account4.currency = 'GBP'
    this.account4.bank = 'RBS'
    this.account4.type = 'Long Term'
    this.account4.bank_img = 'assets/images/rbs_round.png'

    this.account5.account_no = '55555555';
    this.account5.amount = '5000';
    this.account5.currency = 'EUR'
    this.account5.bank = 'RBS'
    this.account5.type = 'Checking'
    this.account5.bank_img = 'assets/images/rbs_round.png'

    this.account6.account_no = '66666666';
    this.account6.amount = '6000';
    this.account6.currency = 'EUR'
    this.account6.bank = 'RBS'
    this.account6.type = 'Short Term'
    this.account6.bank_img = 'assets/images/rbs_round.png'

    this.account7.account_no = '777777777';
    this.account7.amount = '7000';
    this.account7.currency = 'GBP'
    this.account7.bank = 'Starling'
    this.account7.type = 'Long Term'
    this.account7.bank_img = 'assets/images/starling_round.png'

    this.account8.account_no = '888888888';
    this.account8.amount = '8000';
    this.account8.currency = 'USD'
    this.account8.bank = 'Starling'
    this.account8.type = 'Checking'
    this.account8.bank_img = 'assets/images/starling_round.png'

    this.accounts.push(this.account1);
    this.accounts.push(this.account2);
    this.accounts.push(this.account3);
    this.accounts.push(this.account4);
    this.accounts.push(this.account5);
    this.accounts.push(this.account6);
    this.accounts.push(this.account7);
    this.accounts.push(this.account8);
    this.usdFilter();
  }

  usdFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].currency == 'USD'){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptionsBar(this.selectedAccounts);
    this.setPieOptionsBarBanks(this.selectedAccounts);

  }

  gbpFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].currency == 'GBP'){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptionsBar(this.selectedAccounts);
    this.setPieOptionsBarBanks(this.selectedAccounts);

  }

  eurFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].currency == 'EUR'){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptionsBar(this.selectedAccounts);
    this.setPieOptionsBarBanks(this.selectedAccounts);

  }

  setPieOptionsBar(selectedAccounts:Array<any>){
    console.log('setPieOptions');
    this.xAxisData = [];
    for(var i =0; i< selectedAccounts.length; i++){
      if (!this.xAxisData.includes(selectedAccounts[i].type.trim().toUpperCase())){
        this.xAxisData.push(selectedAccounts[i].type.trim().toUpperCase());
      }
    }

    this.dataSeriesSums = [];
    for(var i =0; i<this.xAxisData.length; i++){
      this.dataSeriesSums[i]=0;
    }
    for(var i =0; i< selectedAccounts.length; i++){
      for(var j =0; j<this.xAxisData.length; j++){
        if (selectedAccounts[i].type.trim().toUpperCase()==this.xAxisData[j].trim().toUpperCase()){
          this.dataSeriesSums[j] +=Number(selectedAccounts[i].amount);
        }
      }
    }



    console.log("xAxisData");
    console.log(this.xAxisData);
    console.log("dataSeriesSums");
    console.log(this.dataSeriesSums);

   // const colors: any = config.variables;


    this.optionsBar = {
      backgroundColor: echarts.bg,
      color: ['#0088ff'],
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true,
      },
      xAxis: [
        {
          type: 'category',
          data: this.xAxisData,//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          axisTick: {
            alignWithLabel: true,
          },
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      yAxis: [
        {
          type: 'value',
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          splitLine: {
            lineStyle: {
              color: '#342e73',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      series: [
        {
          name: 'Score',
          type: 'bar',
          barWidth: '60%',
          data:this.dataSeriesSums,//[10, 52, 200, 334, 390, 330, 220],
        },
      ],
    };

    //this.pieService.setOptions(this.dataLegend,this.dataForSeries);
  }

  setPieOptionsBarBanks(selectedAccounts:Array<any>){
    console.log('setPieOptions');
    this.xAxisDataBanks = [];
    for(var i =0; i< selectedAccounts.length; i++){
      if (!this.xAxisDataBanks.includes(selectedAccounts[i].bank.trim().toUpperCase())){
        this.xAxisDataBanks.push(selectedAccounts[i].bank.trim().toUpperCase());
      }
    }

    this.dataSeriesSumsBanks = [];
    for(var i =0; i<this.xAxisDataBanks.length; i++){
      this.dataSeriesSumsBanks[i]=0;
    }
    for(var i =0; i< selectedAccounts.length; i++){
      for(var j =0; j<this.xAxisDataBanks.length; j++){
        if (selectedAccounts[i].bank.trim().toUpperCase()==this.xAxisDataBanks[j].trim().toUpperCase()){
          this.dataSeriesSumsBanks[j] +=Number(selectedAccounts[i].amount);
        }
      }
    }



    console.log("xAxisData");
    console.log(this.xAxisDataBanks);
    console.log("dataSeriesSums");
    console.log(this.dataSeriesSumsBanks);

   // const colors: any = config.variables;


    this.optionsBarBanks = {
      backgroundColor: echarts.bg,
      color: ['#0088ff'],
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true,
      },
      xAxis: [
        {
          type: 'category',
          data: this.xAxisDataBanks,//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          axisTick: {
            alignWithLabel: true,
          },
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      yAxis: [
        {
          type: 'value',
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          splitLine: {
            lineStyle: {
              color: '#342e73',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      series: [
        {
          name: 'Score',
          type: 'bar',
          barWidth: '60%',
          data:this.dataSeriesSumsBanks,//[10, 52, 200, 334, 390, 330, 220],
        },
      ],
    };

    //this.pieService.setOptions(this.dataLegend,this.dataForSeries);
  }
}


@Component({/*Banks */
  selector: 'ngx-tab3',
  template: `
  <div class="row">
  <div class="col-lg-6">
    <nb-card>
      <nb-card-header>
        <div class="row">
          <div [(ngModel)]="dividedButtonGroupOne" ngbRadioGroup
               class="btn-group btn-divided-group btn-outline-divided-group btn-group-full-width col-md-8">
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="nordeaFilter()">
              <input ngbButton type="radio" value="left"> Nordea
            </label>
            <label ngbButtonLabel  class="btn btn-outline-primary btn-sm" (click)="rbsFilter()">
              <input ngbButton type="radio" value="middle"> RBS
            </label>
            <label ngbButtonLabel   class="btn btn-outline-primary btn-sm" (click)="starlingFilter()">
              <input ngbButton type="radio" value="right"> Starling
            </label>
          </div>
        </div>
      </nb-card-header>
      <nb-card-body>
      <div  *ngFor="let account of selectedAccounts">
        <div class="col-md-12">
          <nb-card> 
            <nb-card-header>
            <div>
            <h6 ><b>Account&nbsp;:</b>  &nbsp; {{account.account_no}} &nbsp; - &nbsp; {{account.type}} <img src={{account.bank_img}} style="margin:auto; width:50px;" align="right"/></h6>       
           </div>
            </nb-card-header>
            <nb-card-body>
            <div>
              <h6 ><b>Balance&nbsp;:</b>&nbsp; {{account.amount}}  &nbsp;&nbsp; {{account.currency}}
              <button class="btn btn-primary btn-tn" style="float: right;" >Move Funds</button>&nbsp;&nbsp;
              </h6>  
              </div>            
            </nb-card-body>
          </nb-card>
        </div>
        </div>
      </nb-card-body>
    </nb-card>
  </div>
  <div class="col-lg-6">
  <nb-card>
      <nb-card-body>
        <ngx-echarts-pie [dataLegend]="dataLegend" [dataForSeries]="dataForSeries" [options]="options"></ngx-echarts-pie>
        <ngx-echarts-bar [xAxisData]="xAxisData" [dataSeriesSums]="dataSeriesSums" [options]="optionsBar"></ngx-echarts-bar>
        </nb-card-body>
  </nb-card>
  </div>
</div> 
`,
//providers: [AccountService]
})
export class Tab3Component {
  accounts: Account[] = [];
  selectedAccounts :Account[]   = [];
  account1: Account = new Account();
  account2: Account = new Account();
  account3: Account = new Account();
  account4: Account = new Account();
  account5: Account = new Account();
  account6: Account = new Account();
  account7: Account = new Account();
  account8: Account = new Account();
  options: any = {};
  themeSubscription: any;
  dataLegend :Array<any>;
  dataForSeries :Array<any>;
  optionsBar: any = {};
  themeSubscriptionBar: any;
  xAxisData :Array<any>; // represents the name of the account types
  dataSeriesSums :Array<any>;

  constructor(private accountService: AccountService) {


    
    this.accountService
    .getOverallbalance()
    .then((accounts: Account[]) => {
      this.accounts = this.accounts.concat(accounts.map((account) => {
        if (!account.account_no) {
          account.account_no = 'no number';
        }
        return account;
      }));
    });
    this.account1.account_no = '111111';
    this.account1.amount = '1000';
    this.account1.currency = 'USD'
    this.account1.bank = 'Nordea'
    this.account1.type = 'Checking'
    this.account1.bank_img = 'assets/images/nordea.png'

    this.account2.account_no = '2222222';
    this.account2.amount = '2000';
    this.account2.currency = 'GBP'
    this.account2.bank = 'Nordea'
    this.account2.type = 'Short Term'
    this.account2.bank_img = 'assets/images/nordea.png'

    this.account3.account_no = '33333333';
    this.account3.amount = '3000';
    this.account3.currency = 'USD'
    this.account3.bank = 'Nordea'
    this.account3.type = 'Checking'
    this.account3.bank_img = 'assets/images/nordea.png'

    this.account4.account_no = '4444444444';
    this.account4.amount = '4000';
    this.account4.currency = 'GBP'
    this.account4.bank = 'RBS'
    this.account4.type = 'Long Term'
    this.account4.bank_img = 'assets/images/rbs_round.png'

    this.account5.account_no = '55555555';
    this.account5.amount = '5000';
    this.account5.currency = 'EUR'
    this.account5.bank = 'RBS'
    this.account5.type = 'Checking'
    this.account5.bank_img = 'assets/images/rbs_round.png'

    this.account6.account_no = '66666666';
    this.account6.amount = '6000';
    this.account6.currency = 'EUR'
    this.account6.bank = 'RBS'
    this.account6.type = 'Short Term'
    this.account6.bank_img = 'assets/images/rbs_round.png'

    this.account7.account_no = '777777777';
    this.account7.amount = '7000';
    this.account7.currency = 'GBP'
    this.account7.bank = 'Starling'
    this.account7.type = 'Long Term'
    this.account7.bank_img = 'assets/images/starling_round.png'

    this.account8.account_no = '888888888';
    this.account8.amount = '8000';
    this.account8.currency = 'USD'
    this.account8.bank = 'Starling'
    this.account8.type = 'Checking'
    this.account8.bank_img = 'assets/images/starling_round.png'

    this.accounts.push(this.account1);
    this.accounts.push(this.account2);
    this.accounts.push(this.account3);
    this.accounts.push(this.account4);
    this.accounts.push(this.account5);
    this.accounts.push(this.account6);
    this.accounts.push(this.account7);
    this.accounts.push(this.account8);
    this.nordeaFilter();
  }

  nordeaFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].bank == 'Nordea'){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptions(this.selectedAccounts);
    this.setPieOptionsBar(this.selectedAccounts);

  }

  rbsFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].bank == 'RBS'){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptions(this.selectedAccounts);
    this.setPieOptionsBar(this.selectedAccounts);

  }

  starlingFilter(){
    this.selectedAccounts = [];
    for(var i =0; i< this.accounts.length; i++){
      if(this.accounts[i].bank == 'Starling'){
          this.selectedAccounts.push(this.accounts[i]);
      }
    }
    this.setPieOptions(this.selectedAccounts);
    this.setPieOptionsBar(this.selectedAccounts);
  }

  setPieOptions(selectedAccounts:Array<any>){
    console.log('setPieOptions');
    this.dataLegend = [];
    for(var i =0; i< selectedAccounts.length; i++){
      if (!this.dataLegend.includes(selectedAccounts[i].currency.trim().toUpperCase())){
        this.dataLegend.push(selectedAccounts[i].currency.trim().toUpperCase());
      }
    }

    let dataSeriesSums:number[]= [];
    for(var i =0; i<this.dataLegend.length; i++){
      dataSeriesSums[i]=0;
    }
    for(var i =0; i< selectedAccounts.length; i++){
      for(var j =0; j<this.dataLegend.length; j++){
        if (selectedAccounts[i].currency.trim().toUpperCase()==this.dataLegend[j].trim().toUpperCase()){
          dataSeriesSums[j] +=Number(selectedAccounts[i].amount);
        }
      }
    }

    this.dataForSeries = [];
    for(var i =0; i<this.dataLegend.length; i++){
      this.dataForSeries.push({value: dataSeriesSums[i], name: this.dataLegend[i]});
    }

    console.log("dataLedend");
    console.log(this.dataLegend);
    console.log("dataSeriesSums");
    console.log(dataSeriesSums);
    console.log("dataForSeries");
    console.log(this.dataForSeries);


    this.options = {
      backgroundColor: echarts.bg,
      color: ['#ffa100', '#00d977', '#0088ff'],
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)',
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        data: this.dataLegend,
        textStyle: {
          color: echarts.textColor,
        },
      },
      series: [
        {
          name: 'Currencies',
          type: 'pie',
          radius: '80%',
          center: ['50%', '50%'],
          data:this.dataForSeries,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: echarts.itemHoverShadowColor,
            },
          },
          label: {
            normal: {
              textStyle: {
                color: echarts.textColor,
              },
            },
          },
          labelLine: {
            normal: {
              lineStyle: {
                color: echarts.axisLineColor,
              },
            },
          },
        },
      ],
    };

    //this.pieService.setOptions(this.dataLegend,this.dataForSeries);
  }
  setPieOptionsBar(selectedAccounts:Array<any>){
    console.log('setPieOptions');
    this.xAxisData = [];
    for(var i =0; i< selectedAccounts.length; i++){
      if (!this.xAxisData.includes(selectedAccounts[i].type.trim().toUpperCase())){
        this.xAxisData.push(selectedAccounts[i].type.trim().toUpperCase());
      }
    }

    this.dataSeriesSums = [];
    for(var i =0; i<this.xAxisData.length; i++){
      this.dataSeriesSums[i]=0;
    }
    for(var i =0; i< selectedAccounts.length; i++){
      for(var j =0; j<this.xAxisData.length; j++){
        if (selectedAccounts[i].type.trim().toUpperCase()==this.xAxisData[j].trim().toUpperCase()){
          this.dataSeriesSums[j] +=Number(selectedAccounts[i].amount);
        }
      }
    }



    console.log("xAxisData");
    console.log(this.xAxisData);
    console.log("dataSeriesSums");
    console.log(this.dataSeriesSums);

   // const colors: any = config.variables;


    this.optionsBar = {
      backgroundColor: echarts.bg,
      color: ['#0088ff'],
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow',
        },
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true,
      },
      xAxis: [
        {
          type: 'category',
          data: this.xAxisData,//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          axisTick: {
            alignWithLabel: true,
          },
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      yAxis: [
        {
          type: 'value',
          axisLine: {
            lineStyle: {
              color: '#a1a1e5',
            },
          },
          splitLine: {
            lineStyle: {
              color: '#342e73',
            },
          },
          axisLabel: {
            textStyle: {
              color: '#ffffff',
            },
          },
        },
      ],
      series: [
        {
          name: 'Score',
          type: 'bar',
          barWidth: '60%',
          data:this.dataSeriesSums,//[10, 52, 200, 334, 390, 330, 220],
        },
      ],
    };

    //this.pieService.setOptions(this.dataLegend,this.dataForSeries);
  }
 }
 


@Component({
  selector: 'ngx-tabs',
  styleUrls: ['./tabs.component.scss'],
  templateUrl: './tabs.component.html',
})
export class TabsComponent {

  tabs: any[] = [
    {
      title: 'Accounts',
      route: '/pages/ui-features/tabs/tab1',
    },
    {
      title: 'Currencies',
      route: '/pages/ui-features/tabs/tab2',
    },
    {
      title: 'Banks',
      route: '/pages/ui-features/tabs/tab3',
    }
  ];
  
  

}
