import { TestBed, inject } from '@angular/core/testing';

import { PieChartServiceService } from './pie-chart-service.service';

describe('PieChartServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PieChartServiceService]
    });
  });

  it('should be created', inject([PieChartServiceService], (service: PieChartServiceService) => {
    expect(service).toBeTruthy();
  }));
});
