import { AfterViewInit, Component, OnDestroy, Input } from '@angular/core';
import { NbThemeService } from '@nebular/theme';

@Component({
  selector: 'ngx-echarts-bar',
  template: `
    <div echarts [options]="options" class="echart"></div>
  `,
})
export class EchartsBarComponent implements AfterViewInit, OnDestroy {
  @Input() public options: any = {};
  themeSubscription: any;
  @Input() public xAxisData :Array<any>;
  @Input() public dataSeriesSums :Array<any>;


  constructor(private theme: NbThemeService) {
    console.log('bar constructor');
    this.xAxisData = [];
    this.dataSeriesSums = [];
  }

  ngAfterViewInit() {
    console.log("bar ngAfterViewInit");

    this.themeSubscription = this.theme.getJsTheme().subscribe(config => {

      const colors: any = config.variables;
      const echarts: any = config.variables.echarts;

      this.options = {
        backgroundColor: echarts.bg,
        color: ['#0088ff'],
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true,
        },
        xAxis: [
          {
            type: 'category',
            data: this.xAxisData,//['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            axisTick: {
              alignWithLabel: true,
            },
            axisLine: {
              lineStyle: {
                color: '#a1a1e5',
              },
            },
            axisLabel: {
              textStyle: {
                color: '#ffffff',
              },
            },
          },
        ],
        yAxis: [
          {
            type: 'value',
            axisLine: {
              lineStyle: {
                color: '#a1a1e5',
              },
            },
            splitLine: {
              lineStyle: {
                color: '#342e73',
              },
            },
            axisLabel: {
              textStyle: {
                color: '#ffffff',
              },
            },
          },
        ],
        series: [
          {
            name: 'Score',
            type: 'bar',
            barWidth: '60%',
            data: this.dataSeriesSums,//[10, 52, 200, 334, 390, 330, 220],
          },
        ],
      };
    });
  }

  ngOnDestroy(): void {
    this.themeSubscription.unsubscribe();
  }
}
