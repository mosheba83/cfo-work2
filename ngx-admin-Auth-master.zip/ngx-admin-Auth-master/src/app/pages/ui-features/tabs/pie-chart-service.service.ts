import { Injectable } from '@angular/core';

@Injectable()
export class PieChartServiceService {
  options: any = {};

  constructor() { }

  setOptions(dataLedend:Array<String> ,dataForSeries:any){
    console.log("calling pie service setOptions");
    this.options = {
      backgroundColor: echarts.bg,
      color: ['#ffa100', '#00d977', '#0088ff'],
      tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b} : {c} ({d}%)',
      },
      legend: {
        orient: 'vertical',
        left: 'left',
        data: dataLedend,
        textStyle: {
          color: echarts.textColor,
        },
      },
      series: [
        {
          name: 'Currencies',
          type: 'pie',
          radius: '80%',
          center: ['50%', '50%'],
          data:dataForSeries,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: echarts.itemHoverShadowColor,
            },
          },
          label: {
            normal: {
              textStyle: {
                color: echarts.textColor,
              },
            },
          },
          labelLine: {
            normal: {
              lineStyle: {
                color: echarts.axisLineColor,
              },
            },
          },
        },
      ],
    };
  }



}
