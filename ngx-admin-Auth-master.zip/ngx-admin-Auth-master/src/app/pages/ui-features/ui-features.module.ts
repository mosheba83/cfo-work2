import { NgModule ,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { ThemeModule } from '../../@theme/theme.module';
import { ButtonsModule } from './buttons/buttons.module';
import { UiFeaturesRoutingModule } from './ui-features-routing.module';
import { UiFeaturesComponent } from './ui-features.component';
import { GridComponent } from './grid/grid.component';
import { IconsComponent } from './icons/icons.component';
import { TypographyComponent } from './typography/typography.component';
import { TabsComponent, Tab1Component, Tab2Component,Tab3Component } from './tabs/tabs.component';
import { SearchComponent } from './search-fields/search-fields.component';
import { NgxEchartsModule } from 'ngx-echarts';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ChartModule } from 'angular2-chartjs';
import { PieChartServiceService} from './tabs/pie-chart-service.service';
import { EchartsBarComponent } from './tabs/echarts-bar.component';
import { EchartsPieComponent } from './tabs/echarts-pie.component'; 

const components = [
  UiFeaturesComponent,
  GridComponent,
  IconsComponent,
  TypographyComponent,
  TabsComponent,
  Tab1Component,
  Tab2Component,
  Tab3Component,
  SearchComponent,
  EchartsPieComponent,
  EchartsBarComponent,
];

@NgModule({
  imports: [
    ThemeModule,
    UiFeaturesRoutingModule,
    ButtonsModule,
    ChartModule,
    NgxEchartsModule, NgxChartsModule, 
  ],
  declarations: [
    ...components,
  ],
  entryComponents: [
   
  ],
  providers:[PieChartServiceService],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA ],
})
export class UiFeaturesModule { }
