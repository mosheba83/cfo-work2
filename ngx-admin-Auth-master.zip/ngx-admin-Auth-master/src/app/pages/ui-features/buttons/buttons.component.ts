import { Component } from '@angular/core';
import { GlobalService } from '../../../globalService';
import { AccountService } from '../../account.service';
import {MENU_ITEMS } from '../../../pages/pages-menu'

@Component({
  selector: 'ngx-buttons',
  styleUrls: ['./buttons.component.scss'],
  templateUrl: './buttons.component.html',
})
export class ButtonsComponent {
  firstName:string =  '';
  lastName: string = '';
  constructor(private api:GlobalService, private accountService:AccountService){
    console.log('ngx-buttons constructor');
    this.firstName = accountService.firstName;
    this.lastName = accountService.lastName;

  }
}
