import { Component } from '@angular/core';


@Component({
  selector: 'ngx-newlogin',
  // template: `
  //   <router-outlet></router-outlet>
  // `,
  template: `
      <router-outlet></router-outlet>
`,
})
export class NewloginComponent {
}